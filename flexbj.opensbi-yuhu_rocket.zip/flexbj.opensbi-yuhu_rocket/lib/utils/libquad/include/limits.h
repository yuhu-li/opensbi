/*
 * SPDX-License-Identifier: BSD-2-Clause
 *
 * Copyright (c) 2021 Jessica Clarke <jrtc27@jrtc27.com>
 */

#ifndef __LIMITS_H__
#define __LIMITS_H__

#define CHAR_BIT 8

#endif
