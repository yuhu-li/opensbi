/* SPDX-License-Identifier: BSD-2-Clause */

#include <sbi/riscv_asm.h>
#include <sbi/riscv_encoding.h>
#include <sbi/riscv_io.h>
#include <sbi/sbi_console.h>
#include <sbi/sbi_const.h>
#include <sbi/sbi_hart.h>
#include <sbi/sbi_hartmask.h>
#include <sbi/sbi_platform.h>
#include <sbi_utils/fdt/fdt_helper.h>
#include <sbi_utils/fdt/fdt_fixup.h>
#include <sbi_utils/irqchip/fdt_irqchip.h>
#include <sbi_utils/serial/fdt_serial.h>
#include <sbi_utils/timer/fdt_timer.h>
#include <sbi_utils/ipi/fdt_ipi.h>
#include <sbi_utils/serial/uart8250.h>

#define ROCKET_UART_ADDR			0x60000000
#define ROCKET_UART_FREQ			50000000
#define ROCKET_UART_BAUDRATE			38400
#define ROCKET_UART_REG_SHIFT			0
#define ROCKET_UART_REG_WIDTH			4

static int rocket_final_init(bool cold_boot)
{
	void *fdt;

	if (!cold_boot)
		return 0;

	fdt = fdt_get_address();
	fdt_fixups(fdt);

	return 0;
}

static int rocket_console_init(void)
{
	return uart8250_init(ROCKET_UART_ADDR,
			     ROCKET_UART_FREQ,
			     ROCKET_UART_BAUDRATE,
			     ROCKET_UART_REG_SHIFT,
			     ROCKET_UART_REG_WIDTH);
}

/*
 * Platform descriptor.
 */
const struct sbi_platform_operations platform_ops = {
	.final_init = rocket_final_init,
	.console_init = rocket_console_init,
	.irqchip_init = fdt_irqchip_init,
	.irqchip_exit = fdt_irqchip_exit,
	.ipi_init = fdt_ipi_init,
	.ipi_exit = fdt_ipi_exit,
	.timer_init = fdt_timer_init,
	.timer_exit = fdt_timer_exit,
};

const struct sbi_platform platform = {
	.opensbi_version = OPENSBI_VERSION,
	.platform_version = SBI_PLATFORM_VERSION(0x0, 0x01),
	.name = "ROCKET RISC-V",
	.features = SBI_PLATFORM_DEFAULT_FEATURES,
	.hart_count = SBI_HARTMASK_MAX_BITS,
	.hart_stack_size = SBI_PLATFORM_DEFAULT_HART_STACK_SIZE,
	.platform_ops_addr = (unsigned long)&platform_ops
};
